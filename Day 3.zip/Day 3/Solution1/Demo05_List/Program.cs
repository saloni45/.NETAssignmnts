﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Demo05_List
{
    class Program
    {
        static void Main(string[] args)
        {
            var ObjList = new List<int>();
            var ObjList1 = new List<string>();
            var ObjList2 = new List<Employee>();

            ObjList.Add(10);
            ObjList.Add(20);
            ObjList.Add(30);

            ObjList1.Add("Jojo");
            ObjList1.Add("Sam");

          //  ObjList2.Add("Demo");
            //ObjList2.Add(10);
            ObjList2.Add(new Employee());

           
             int sum 0;
            foreach( var num in ObjList)
            {
                sum = sum + num;
            }


        }
    }
}
