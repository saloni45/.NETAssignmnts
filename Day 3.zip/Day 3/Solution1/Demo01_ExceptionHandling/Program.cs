﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo01_ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {

            int numerator, denominator, result;
            try
            {


                Console.WriteLine("Enter Numerator");
                numerator = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Denominator");
                denominator = Convert.ToInt32(Console.ReadLine());
                if(denominator==0)
                {
                    //  var ar = new ArgumentException("Invalid value for denominator. cannot be 0");
                    // throw ar;
                    throw new ArgumentException("Invalid value for denominator, cannot be 0");
                }

                result = numerator / denominator;

                Console.WriteLine("Result of Division :" + result);
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("Error Dividing numbers:" + ex.Message);
                Console.WriteLine("STACK TRACE : " + ex.StackTrace);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Error Converting values:" + ex.Message);
                Console.WriteLine("STACK TRACE : " + ex.StackTrace);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unknown exception:" + ex.Message);
                Console.WriteLine("STACK TRACE : " + ex.StackTrace);
            }
            finally
            {
                Console.WriteLine("Press any key to exit");
            }
            Console.ReadKey();

        }
    }
}
