﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo06_ListCrud
{class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double salary { get; set; }

    }
    class Program
    {
       
        static void Main(string[] args)
        {
            var EmployeeList = new List<Employee>();
            int Choice = -1;
            while(true)
            {
                Console.WriteLine("\n1.Add Employee");
                Console.WriteLine("2.List All Employees");
                Console.WriteLine("3. Search employee id");
                Console.WriteLine("4. update employee");
                Console.WriteLine("5. delete employee");
                Console.WriteLine("6.sore employes");
                Console.WriteLine("7. exit");
                    Console.WriteLine("your choice"); ;
                Choice = Convert.ToInt32(Console.ReadLine());

                switch(Choice)
                {
                    case 1:
                        var EmployeeToAdd = new Employee();
                        Console.WriteLine("Enter Id");
                        EmployeeToAdd.ID Convert.(Console.ReadLine());

                        Console.WriteLine("Enter Id");
                        EmployeeToAdd.Convert.ToInte32(Console.ReadLine());

                        Console.WriteLine("Enter Id");
                        EmployeeToAdd.Convert.ToInte32(Console.ReadLine());
                        EmployeeList.Add(EmployeeToAdd);
                        break;
                }
            }
        }
    }
}
