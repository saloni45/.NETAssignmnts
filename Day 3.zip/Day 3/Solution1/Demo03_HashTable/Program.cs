﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo03_HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            var Table = new Hashtable();
            Table.Add(101, "Jojo");
            Table.Add(102, "Jam");
            Table.Add(103, "Bob");
            Table.Add(104, "Sarah");
            Console.WriteLine("Total Items:" + Table.Count);
            foreach (var key in Table.Keys)
                {
                Console.WriteLine($"Key ={key}, value = {Table[key]}");

            }





            Console.ReadKey();
        }
    }
}
