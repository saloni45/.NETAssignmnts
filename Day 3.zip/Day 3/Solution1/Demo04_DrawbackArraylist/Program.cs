﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo04_DrawbackArraylist
{
    class Program
    {
        static void Main(string[] args)
        {
            var Numbers = new ArrayList();
            Numbers.Add(10);  //Implicit casting to object
            Numbers.Add(20);
            Numbers.Add(30);
            Numbers.Add(40);
            Numbers.Add(50);
            Numbers.Add("Jojo"); // Not strongly i.e they are loosely types

            int sum = 0;
            foreach (var obj in Numbers)
            {
                sum = sum + Convert.ToInt32(obj);  //Explicit casting to Int32

            }
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
