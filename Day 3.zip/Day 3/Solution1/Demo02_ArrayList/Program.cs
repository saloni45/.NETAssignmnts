﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
namespace Demo02_ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            var ObjList = new ArrayList();
            ObjList.Add("Jojo");

            ObjList.Add("Sarah");
            ObjList.Add("Jojo");
            ObjList.Add("Sam");
            Console.WriteLine("Total Items:" + ObjList.Count);
            Console.WriteLine("Iterating using a for Loop");
            for(int Index=0; Index<ObjList.Count;Index++)
            {
                Console.WriteLine(ObjList[Index]);
            }
            Console.WriteLine("Itearing");
            foreach(var obj in ObjList)
            {
                Console.WriteLine(obj);
            }
            ObjList.Remove("Sam");
            Console.WriteLine("total items after removing : " + ObjList.Count);
            Console.ReadKey();
            
        }

    }
}
