﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        static Dictionary<string, string> 
         Tables = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter your choice");
                Console.WriteLine("1.Add details");
                Console.WriteLine("2.Remove distict name on base of RTO code");
                Console.WriteLine("3.List of all RTOCodes and distric name");
                Console.WriteLine("4.Exit");


                int Choice = Convert.ToInt32(Console.ReadLine());

                switch (Choice)
                {
                    case 1:
                        AddRTOCodes();
                        Console.WriteLine("entered successfully");
                        break;
                    case 2: RemoveDetails(); break;
                    case 3: ListDetails(); break;
                    case 4:Environment.Exit(0);break;
                    default: Console.WriteLine("Enter right choice"); break;
                }
            }
        }
        private static void AddRTOCodes()
        {
            Console.WriteLine("Enter RTO code ");
            string RTOCode = Console.ReadLine();

            Console.WriteLine("Enter district name");
            string DistrictName = Console.ReadLine();

            Tables.Add(RTOCode, DistrictName);

        }
        private static void ListDetails()
        {
            foreach (var key in Tables.Keys)
            {

                Console.WriteLine($"RTO Code={key}, District={Tables[key]}");
            }
        }
        private static void RemoveDetails()
        {
            Console.WriteLine("Enter RTO code for delete");
            string RtoCode = Console.ReadLine();
            Boolean Found = false;
            foreach (var key in Tables.Keys)
            {
                if (key == RtoCode)
                {
                   Tables.Remove(RtoCode);
                    Console.WriteLine("Found and deleted");
                    Found = true;
                    break;
                }

            }
            if (!Found)
            {
                Console.WriteLine("Data not found");
            }

        }
    }
}