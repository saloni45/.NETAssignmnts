﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XyzBankLtd
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean record = false;
            int FirstRecord = 1;
            while (FirstRecord == 1)
            {
                try
                {
                    var acc = new account();
                    Console.WriteLine("Enter Acount No");
                    int AccountNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Customer Name");
                    string CustomerName = Console.ReadLine();

                    Console.WriteLine("Account No is:" + AccountNo);
                    Console.WriteLine("Customer Name is:" + CustomerName);
                    FirstRecord = 0;
                    record = true;
                }
                catch(ArgumentException)
                {
                    Console.WriteLine("Enter valid details");
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                var Obj = new account();
                while(record)
                {
                    Console.WriteLine("Enter your choice what you want to do");
                    Console.WriteLine("1.Withdraw");
                    Console.WriteLine("2.Deposit");
                    Console.WriteLine("3.Exit");
                    int Choice = Convert.ToInt32(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:

                            try
                            {
                                Console.WriteLine("Enter amount to perform operation");
                                int Amount = Convert.ToInt32(Console.ReadLine());
                                Obj.WithDraw(Amount);
                            }
                            catch (ArgumentException )
                            {
                                Console.WriteLine("Insufficient balance");
                            }
                            
                            break;

                        case 2:

                            try
                            {
                                Console.WriteLine("Enter amount to perform operation");
                                int Amount = Convert.ToInt32(Console.ReadLine());
                                Obj.Deposit(Amount);
                            }
                            catch (ArgumentException)
                            {
                                Console.WriteLine("Please enter value more then 0");
                            }
                            break;
                        case 3:Environment.Exit(0);break;

                        default:
                            Console.WriteLine("Please enter valid choice");
                            break;
                    }

                }
                Console.ReadKey();
            }





        }
    }
}

