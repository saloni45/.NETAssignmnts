﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XyzBankLtd
{
    class account
    {
        public int AccountNo
        {
            get { return AccountNo; }
            set { AccountNo = value; }
        }

        
        public int CustomerName
        {
            get { return CustomerName; }
            set { CustomerName = value; }
        }

        private int Balance = 2000;
        public int balance
        {
            get { return Balance; }
        }

        public void WithDraw(int a)
        {

            if (a >= Balance)
            {
                throw new ArgumentException("Insufficient Balance .....");
            }
            else
            {
                Balance -= a;
                Console.WriteLine("Your balance is :" + Balance);
            }


        }

        public void Deposit(int a)
        {
            if (a <= 0)
            {
                throw new ArgumentException("Invalid value of amount .....");
            }
            else
            {
                Balance += a;
                Console.WriteLine("Your balance is :" + Balance);
            }
        }




    }
}
       
