﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
   
}
class Employee : IComparable<Employee>
{
    public int ID { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public double Salary { get; set; }
    public string Location { get; set; }

    public int CompareTo(Employee other)
    {

        return this.ID.CompareTo(other.ID);
    }

    public override string ToString()
    {
        return $"{this.ID}\t\t{this.Name}\t\t {this.Email}\t\t{this.Salary}\t\t {this.Location}";
    }
}